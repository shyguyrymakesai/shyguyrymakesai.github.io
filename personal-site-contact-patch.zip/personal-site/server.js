// server.js (ESM because package.json has "type": "module")
import express from 'express';
import cors from 'cors';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';
const API_KEY = process.env.API_KEY || null; // optional
const DATA_DIR = process.env.CONTACT_DIR || path.join(__dirname, 'server_data', 'contacts');

// Basic CORS (allow same-origin or configured origin)
app.use(cors({ origin: ALLOWED_ORIGIN === '*' ? true : ALLOWED_ORIGIN, credentials: false }));
app.use(express.json({ limit: '1mb' }));

// Health
app.get('/health', (_req, res) => res.json({ ok: true }));

// Ensure write dir exists
async function ensureDir(dir) {
  await fs.mkdir(dir, { recursive: true }).catch(() => {});
}

// Minimal rate-limit (per-IP, 10/min)
const hits = new Map();
function rateLimit(req, res, next) {
  const ip = req.headers['x-forwarded-for']?.toString().split(',')[0].trim() || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const windowMs = 60_000;
  const limit = 10;
  const entry = hits.get(ip) || [];
  const recent = entry.filter((t) => now - t < windowMs);
  recent.push(now);
  hits.set(ip, recent);
  if (recent.length > limit) return res.status(429).json({ error: 'Too many requests' });
  next();
}

app.post('/api/contact', rateLimit, async (req, res) => {
  try {
    if (API_KEY) {
      const auth = req.headers['authorization'] || '';
      const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
      if (token !== API_KEY) return res.status(401).json({ error: 'Unauthorized' });
    }

    const { firstName, lastName, email, message, ...rest } = req.body || {};
    if (!firstName || !lastName || !email || !message) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    await ensureDir(DATA_DIR);
    const ts = new Date().toISOString().replace(/[:.]/g, '-');
    const file = path.join(DATA_DIR, `${ts}--${(email||'anon').replace(/[^a-zA-Z0-9_.-]/g,'_')}.json`);
    const record = {
      firstName, lastName, email, message,
      meta: {
        receivedAt: new Date().toISOString(),
        ip: req.headers['x-forwarded-for'] || req.socket.remoteAddress || null,
        userAgent: req.headers['user-agent'] || null,
      },
      ...rest,
    };
    await fs.writeFile(file, JSON.stringify(record, null, 2), 'utf8');

    res.json({ ok: true, saved: path.basename(file) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

app.listen(PORT, () => {
  console.log(`[contact-api] listening on http://localhost:${PORT}`);
});
