Personal Site — Contact Backend + Frontend Delta
================================================

This patch includes:
  • server.js  — Express API (POST /api/contact) that saves messages to disk
  • .env.example — Config for PORT, ALLOWED_ORIGIN, API_KEY, CONTACT_DIR
  • src/contexts/config.js — defaults CONTACT_ENDPOINT to '/api/contact'
  • src/pages/ContactPage.jsx — outbox + Sync now UI (from Delta #2)
  • src/pages/HomePage.jsx — proof section (from Delta #2)
  • package.json — adds 'cors' dep and 'dev:api' script

Local dev (two terminals):
  1) API:  cd personal-site && npm i && npm run dev:api
  2) Web:  npm run dev
     Then open http://localhost:5173  (frontend) and POSTs will go to http://localhost:3001/api/contact
     If you want to point the frontend to a remote API, set VITE_CONTACT_ENDPOINT accordingly.

Deploy options:
  • Same-origin: host both the built site and server.js behind one domain (recommended). Keep CONTACT_ENDPOINT='/api/contact'.
  • Separate: deploy API to Render/Fly/Hetzner. Then set VITE_CONTACT_ENDPOINT to https://your-api.yourdomain.com/api/contact
    (and set ALLOWED_ORIGIN to your site URL).

Security (optional):
  • Set API_KEY in the server env. The server will then require 'Authorization: Bearer <API_KEY>'.
    You can add this header to the front-end by editing ContactPage.jsx sync function, or set window.__CONTACT_ENDPOINT__
    to a proxy that injects the header.

Files in this zip are positioned relative to the repo root (contains package.json). Overwrite existing files as needed.
